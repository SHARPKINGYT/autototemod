
package com.example;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;

public class AutoTotem implements ModInitializer {

    @Override
    public void onInitialize() {
        ServerTickEvents.START_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                if (player.getHealth() <= 0.0F && tryConsumeTotem(player)) {
                    player.setHealth(1.0F);
                    player.clearStatusEffects();
                    player.addStatusEffect(StatusEffects.REGENERATION.createEffect(900, 1));
                    player.addStatusEffect(StatusEffects.ABSORPTION.createEffect(100, 1));
                }
            }
        });
    }

    private boolean tryConsumeTotem(ServerPlayerEntity player) {
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.getItem() == Items.TOTEM_OF_UNDYING) {
                stack.decrement(1);
                return true;
            }
        }
        return false;
    }
}
