// Main Mod Class package com.sharpkingyt.autototem;

import net.fabricmc.api.ModInitializer; import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents; import net.minecraft.item.ItemStack; import net.minecraft.item.Items; import net.minecraft.server.network.ServerPlayerEntity;

public class AutoTotemMod implements ModInitializer {

@Override
public void onInitialize() {
    ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, damageAmount) -> {
        if (entity instanceof ServerPlayerEntity player) {
            return tryConsumeTotem(player);
        }
        return true;
    });
}

private boolean tryConsumeTotem(ServerPlayerEntity player) {
    for (int i = 0; i < player.getInventory().size(); i++) {
        ItemStack stack = player.getInventory().getStack(i);
        if (stack.getItem() == Items.TOTEM_OF_UNDYING) {
            stack.decrement(1);
            player.setHealth(1.0F);
            player.clearStatusEffects();
            player.getWorld().sendEntityStatus(player, (byte) 35);
            return false;
        }
    }
    return true;
}

}

