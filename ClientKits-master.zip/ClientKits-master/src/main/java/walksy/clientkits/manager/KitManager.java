package walksy.clientkits.manager;

import net.minecraft.nbt.NbtList;

import java.util.HashMap;
import java.util.Map;

public class KitManager {

    public static final Map<String, NbtList> kits = new HashMap<>();
}
