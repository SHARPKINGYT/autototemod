package com.yourname.autototem;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class AutoTotemClient implements ClientModInitializer {
    private float lastHealth = 20.0F;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ClientPlayerEntity player = MinecraftClient.getInstance().player;
            if (player == null || player.isCreative() || player.isSpectator()) return;

            float currentHealth = player.getHealth() + player.getAbsorptionAmount();

            if (currentHealth < lastHealth) {
                if (currentHealth <= 0.5F && !player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                    int slot = findTotemInInventory(player.getInventory());
                    if (slot != -1) {
                        swapToOffhand(slot);
                    }
                }
            }

            lastHealth = currentHealth;
        });
    }

    private int findTotemInInventory(PlayerInventory inv) {
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.getItem() == Items.TOTEM_OF_UNDYING) {
                return i;
            }
        }
        return -1;
    }

    private void swapToOffhand(int slot) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.interactionManager != null) {
            mc.interactionManager.clickSlot(0, slot, 0, net.minecraft.screen.slot.SlotActionType.PICKUP, mc.player);
            mc.interactionManager.clickSlot(0, 45, 0, net.minecraft.screen.slot.SlotActionType.PICKUP, mc.player);
        }
    }
}