package com.maceritual.utils;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.Arrays;

public class ItemUtils {
    
    public static final NamespacedKey BROKEN_MACE_KEY = new NamespacedKey("maceritual", "broken_mace");
    public static final NamespacedKey TRUE_MACE_KEY = new NamespacedKey("maceritual", "true_mace");
    
    public static ItemStack createBrokenMace() {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName("§8Broken Mace");
            meta.setLore(Arrays.asList(
                "§7A shattered weapon of legend,",
                "§7waiting to be reborn through ritual.",
                "",
                "§c⚠ COMPLETELY USELESS ⚠",
                "§8• Cannot deal damage",
                "§8• Cannot break blocks", 
                "§8• Feels lifeless in your hands",
                "",
                "§5Place in ritual beacon to awaken..."
            ));
            meta.setUnbreakable(true);
            meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
            
            // Add NBT tag
            meta.getPersistentDataContainer().set(BROKEN_MACE_KEY, PersistentDataType.BOOLEAN, true);
            
            item.setItemMeta(meta);
        }
        
        return item;
    }
    
    public static ItemStack createTrueMace() {
        // Create a normal vanilla mace - no enchantments, no special properties
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName("§6The One True Mace");
            meta.setLore(Arrays.asList("§7Forged through ritual and blood."));
            
            // Add NBT tag for identification
            meta.getPersistentDataContainer().set(TRUE_MACE_KEY, PersistentDataType.BOOLEAN, true);
            
            item.setItemMeta(meta);
        }
        
        return item;
    }
    
    public static boolean isBrokenMace(ItemStack item) {
        if (item == null || item.getType() != Material.MACE) return false;
        
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        
        return meta.getPersistentDataContainer().has(BROKEN_MACE_KEY, PersistentDataType.BOOLEAN);
    }
    
    public static boolean isTrueMace(ItemStack item) {
        if (item == null || item.getType() != Material.MACE) return false;
        
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        
        return meta.getPersistentDataContainer().has(TRUE_MACE_KEY, PersistentDataType.BOOLEAN);
    }
}