package com.maceritual.managers;

import com.maceritual.MaceRitualPlugin;
import com.maceritual.utils.ItemUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;

import java.util.Iterator;
import java.util.List;

public class RecipeManager {
    
    private final MaceRitualPlugin plugin;
    private NamespacedKey brokenMaceKey;
    
    public RecipeManager(MaceRitualPlugin plugin) {
        this.plugin = plugin;
        this.brokenMaceKey = new NamespacedKey(plugin, "broken_mace");
    }
    
    public void registerBrokenMaceRecipe() {
        // Remove existing recipe if it exists
        removeBrokenMaceRecipe();
        
        // Remove all vanilla mace recipes
        removeVanillaMaceRecipes();
        
        ItemStack brokenMace = ItemUtils.createBrokenMace();
        List<String> ingredients = plugin.getConfigManager().getRecipeIngredients();
        
        if (plugin.getConfigManager().isRecipeShaped()) {
            createShapedRecipe(brokenMace, ingredients);
        } else {
            createShapelessRecipe(brokenMace, ingredients);
        }
    }
    
    private void createShapelessRecipe(ItemStack result, List<String> ingredients) {
        ShapelessRecipe recipe = new ShapelessRecipe(brokenMaceKey, result);
        
        for (String ingredient : ingredients) {
            try {
                Material material = Material.valueOf(ingredient.toUpperCase());
                recipe.addIngredient(material);
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Invalid material in recipe: " + ingredient);
            }
        }
        
        Bukkit.addRecipe(recipe);
        plugin.getLogger().info("Registered shapeless Broken Mace recipe");
    }
    
    private void createShapedRecipe(ItemStack result, List<String> ingredients) {
        ShapedRecipe recipe = new ShapedRecipe(brokenMaceKey, result);
        
        // Create 3x3 grid from ingredients
        String[] grid = new String[9];
        for (int i = 0; i < 9; i++) {
            if (i < ingredients.size()) {
                grid[i] = ingredients.get(i);
            } else {
                grid[i] = "AIR";
            }
        }
        
        // Build the shape pattern
        StringBuilder row1 = new StringBuilder();
        StringBuilder row2 = new StringBuilder();
        StringBuilder row3 = new StringBuilder();
        
        char currentChar = 'A';
        java.util.Map<String, Character> materialToChar = new java.util.HashMap<>();
        
        // Process each row
        for (int row = 0; row < 3; row++) {
            StringBuilder currentRow = (row == 0) ? row1 : (row == 1) ? row2 : row3;
            
            for (int col = 0; col < 3; col++) {
                int index = row * 3 + col;
                String material = grid[index];
                
                if (material.equals("AIR") || material.isEmpty()) {
                    currentRow.append(" ");
                } else {
                    if (!materialToChar.containsKey(material)) {
                        materialToChar.put(material, currentChar++);
                    }
                    currentRow.append(materialToChar.get(material));
                }
            }
        }
        
        // Set the shape (remove empty rows/columns)
        String[] shape = {row1.toString(), row2.toString(), row3.toString()};
        
        // Trim empty rows from top and bottom
        int firstNonEmpty = -1, lastNonEmpty = -1;
        for (int i = 0; i < 3; i++) {
            if (!shape[i].trim().isEmpty()) {
                if (firstNonEmpty == -1) firstNonEmpty = i;
                lastNonEmpty = i;
            }
        }
        
        if (firstNonEmpty == -1) {
            // All empty, create a simple single-item recipe
            recipe.shape("A");
            recipe.setIngredient('A', Material.valueOf(ingredients.get(0)));
        } else {
            // Create trimmed shape
            String[] trimmedShape = new String[lastNonEmpty - firstNonEmpty + 1];
            for (int i = 0; i < trimmedShape.length; i++) {
                trimmedShape[i] = shape[firstNonEmpty + i];
            }
            
            recipe.shape(trimmedShape);
            
            // Set ingredients for each character
            for (java.util.Map.Entry<String, Character> entry : materialToChar.entrySet()) {
                try {
                    Material material = Material.valueOf(entry.getKey().toUpperCase());
                    recipe.setIngredient(entry.getValue(), material);
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().warning("Invalid material in shaped recipe: " + entry.getKey());
                }
            }
        }
        
        Bukkit.addRecipe(recipe);
        plugin.getLogger().info("Registered shaped Broken Mace recipe with pattern");
    }
    
    public void removeBrokenMaceRecipe() {
        Iterator<Recipe> iterator = Bukkit.recipeIterator();
        while (iterator.hasNext()) {
            Recipe recipe = iterator.next();
            if (recipe instanceof ShapedRecipe) {
                ShapedRecipe shaped = (ShapedRecipe) recipe;
                if (shaped.getKey().equals(brokenMaceKey)) {
                    iterator.remove();
                    break;
                }
            } else if (recipe instanceof ShapelessRecipe) {
                ShapelessRecipe shapeless = (ShapelessRecipe) recipe;
                if (shapeless.getKey().equals(brokenMaceKey)) {
                    iterator.remove();
                    break;
                }
            }
        }
    }
    
    private void removeVanillaMaceRecipes() {
        Iterator<Recipe> iterator = Bukkit.recipeIterator();
        int removedCount = 0;
        
        while (iterator.hasNext()) {
            Recipe recipe = iterator.next();
            ItemStack result = recipe.getResult();
            
            // Check if the recipe result is a vanilla mace (not our custom ones)
            if (result.getType() == Material.MACE && 
                !ItemUtils.isBrokenMace(result) && 
                !ItemUtils.isTrueMace(result)) {
                iterator.remove();
                removedCount++;
            }
        }
        
        if (removedCount > 0) {
            plugin.getLogger().info("Removed " + removedCount + " vanilla mace recipe(s)");
        }
    }
    
    public void reloadRecipe() {
        registerBrokenMaceRecipe();
    }
}