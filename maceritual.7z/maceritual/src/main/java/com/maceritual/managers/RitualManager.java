package com.maceritual.managers;

import com.maceritual.MaceRitualPlugin;
import com.maceritual.utils.ItemUtils;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class RitualManager {
    
    private final MaceRitualPlugin plugin;
    private Location ritualLocation;
    private BukkitTask ritualTask;
    private BukkitTask particleTask;
    private BukkitTask broadcastTask;
    private BukkitTask bossBarTask;
    private BossBar ritualBossBar;
    private int remainingTime;
    private int totalTime;
    private boolean ritualActive = false;
    
    public RitualManager(MaceRitualPlugin plugin) {
        this.plugin = plugin;
    }
    
    public boolean isRitualActive() {
        return ritualActive;
    }
    
    public Location getRitualLocation() {
        return ritualLocation;
    }
    
    public boolean startRitual(Location beaconLocation, Player player) {
        if (ritualActive) {
            player.sendMessage("§cA ritual is already in progress!");
            return false;
        }
        
        if (!beaconLocation.getWorld().getEnvironment().equals(World.Environment.NORMAL)) {
            player.sendMessage("§cRituals can only be performed in the Overworld!");
            return false;
        }
        
        // Check one-time system for ritual completion
        if (plugin.getConfigManager().isOneTimeSystemEnabled() && 
            plugin.getConfigManager().isRitualCompleted()) {
            player.sendMessage("§c✗ The Mace Ritual has already been completed once!");
            player.sendMessage("§7Only one ritual can ever be performed on this server.");
            player.sendMessage("§7The One True Mace has already been forged.");
            player.sendMessage("§7Contact an admin if you need to reset the system.");
            return false;
        }
        
        ritualLocation = beaconLocation.clone();
        ritualActive = true;
        remainingTime = plugin.getConfigManager().getRitualDuration();
        totalTime = remainingTime;
        
        // Make beacon indestructible
        Block beacon = beaconLocation.getBlock();
        beacon.setMetadata("ritual_protected", new FixedMetadataValue(plugin, true));
        
        // Protect the 3x3 iron platform under the beacon
        protectIronPlatform(beaconLocation, true);
        
        // Create and start boss bar
        createBossBar();
        
        // Start particle effects
        startParticleEffects();
        
        // Start broadcast timer (separate from boss bar)
        startBroadcastTimer();
        
        // Start boss bar updater (this handles the main timing)
        startBossBarUpdater();
        
        // Initial broadcast
        broadcastRitualStart();
        
        return true;
    }
    
    private void startRitualTimer() {
        // Remove this method - we'll use the boss bar updater to handle timing
        // This was causing conflicts with the boss bar timer
    }
    
    private void startParticleEffects() {
        particleTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (!ritualActive || ritualLocation == null) {
                    cancel();
                    return;
                }
                
                World world = ritualLocation.getWorld();
                if (world == null) return;
                
                // Enhanced visual effects for the ritual
                double centerX = ritualLocation.getX() + 0.5;
                double centerY = ritualLocation.getY() + 1;
                double centerZ = ritualLocation.getZ() + 0.5;
                
                // Swirling smoke particles in a 5-block circle
                for (int i = 0; i < 30; i++) { // More particles for larger circle
                    double angle = (System.currentTimeMillis() / 100.0 + i * 12) % 360;
                    double radians = Math.toRadians(angle);
                    double x = centerX + Math.cos(radians) * 5.0; // Increased to 5 blocks
                    double z = centerZ + Math.sin(radians) * 5.0; // Increased to 5 blocks
                    
                    world.spawnParticle(Particle.LARGE_SMOKE, x, centerY, z, 1, 0, 0, 0, 0);
                }
                
                // Add mystical purple particles rising from the beacon
                for (int i = 0; i < 5; i++) {
                    double offsetX = (Math.random() - 0.5) * 1.5;
                    double offsetZ = (Math.random() - 0.5) * 1.5;
                    double offsetY = Math.random() * 3;
                    
                    world.spawnParticle(Particle.WITCH, 
                        centerX + offsetX, centerY + offsetY, centerZ + offsetZ, 
                        1, 0, 0, 0, 0);
                }
                
                // Add soul particles for mystical effect
                if (Math.random() < 0.3) { // 30% chance each tick
                    world.spawnParticle(Particle.SOUL, 
                        centerX + (Math.random() - 0.5) * 3, 
                        centerY + Math.random() * 2, 
                        centerZ + (Math.random() - 0.5) * 3, 
                        1, 0, 0, 0, 0);
                }
                
                // Play ambient sound every 5 seconds
                if (System.currentTimeMillis() % 5000 < 100) {
                    world.playSound(ritualLocation, Sound.BLOCK_BEACON_AMBIENT, 0.5f, 0.8f);
                }
            }
        }.runTaskTimer(plugin, 0L, 5L); // Run every 5 ticks
    }
    
    private void startBroadcastTimer() {
        int interval = plugin.getConfigManager().getBroadcastInterval();
        
        broadcastTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (!ritualActive) {
                    cancel();
                    return;
                }
                
                // Don't decrement time here - let boss bar handle it
                if (remainingTime > 0) {
                    broadcastRitualProgress();
                }
            }
        }.runTaskTimer(plugin, interval * 20L, interval * 20L);
    }
    
    private void broadcastRitualStart() {
        String message = String.format("§c⚠️ A ritual has begun at X:%d Y:%d Z:%d in the Overworld!", 
            ritualLocation.getBlockX(), ritualLocation.getBlockY(), ritualLocation.getBlockZ());
        Bukkit.broadcastMessage(message);
    }
    
    private void broadcastRitualProgress() {
        int minutes = remainingTime / 60;
        String message = String.format("§e⏰ %d minutes remain! Ritual at X:%d Y:%d Z:%d", 
            minutes, ritualLocation.getBlockX(), ritualLocation.getBlockY(), ritualLocation.getBlockZ());
        Bukkit.broadcastMessage(message);
    }
    
    private void completeRitual() {
        if (!ritualActive || ritualLocation == null) return;
        
        World world = ritualLocation.getWorld();
        if (world == null) return;
        
        // Enhanced completion effects - but drop mace AFTER lightning to prevent destruction
        world.strikeLightning(ritualLocation);
        
        // Play dramatic completion sounds
        world.playSound(ritualLocation, Sound.ENTITY_ENDER_DRAGON_DEATH, 1.0f, 1.2f);
        world.playSound(ritualLocation, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
        
        // Create explosion particle effect
        world.spawnParticle(Particle.EXPLOSION_EMITTER, 
            ritualLocation.getX() + 0.5, ritualLocation.getY() + 1, ritualLocation.getZ() + 0.5, 
            1, 0, 0, 0, 0);
        
        // Create golden particle burst
        for (int i = 0; i < 50; i++) {
            double angle = Math.random() * 2 * Math.PI;
            double radius = Math.random() * 3;
            double x = ritualLocation.getX() + 0.5 + Math.cos(angle) * radius;
            double z = ritualLocation.getZ() + 0.5 + Math.sin(angle) * radius;
            double y = ritualLocation.getY() + 1 + Math.random() * 2;
            
            world.spawnParticle(Particle.TOTEM_OF_UNDYING, x, y, z, 1, 0, 0, 0, 0);
        }
        
        // Store location before cleanup
        final Location maceDropLocation = ritualLocation.clone().add(0, 2, 0);
        
        // Mark ritual as completed in one-time system
        if (plugin.getConfigManager().isOneTimeSystemEnabled()) {
            plugin.getConfigManager().setRitualCompleted(true);
            plugin.getLogger().info("Ritual completed - marked as one-time completed");
        }
        
        // Final broadcast
        String message = String.format("§6⚔️ The Ritual is complete! The One True Mace has appeared at X:%d Y:%d Z:%d!", 
            ritualLocation.getBlockX(), ritualLocation.getBlockY(), ritualLocation.getBlockZ());
        Bukkit.broadcastMessage(message);
        
        // Cleanup BEFORE scheduling the mace drop
        cleanup();
        
        // Wait a moment after lightning, then drop the mace safely
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            // Drop The One True Mace after lightning effects
            ItemStack trueMace = ItemUtils.createTrueMace();
            plugin.getLogger().info("Dropping True Mace at location: " + maceDropLocation);
            plugin.getLogger().info("True Mace item: " + trueMace);
            
            // Drop the mace at the stored safe location
            world.dropItemNaturally(maceDropLocation, trueMace);
            plugin.getLogger().info("True Mace dropped successfully at: " + maceDropLocation);
        }, 40L); // Wait 2 seconds after lightning to be extra safe
    }
    
    public void cancelRitual() {
        if (!ritualActive) return;
        
        cleanup();
        Bukkit.broadcastMessage("§c⚠️ The ritual has been forcefully canceled by an administrator!");
    }
    
    public void cleanup() {
        ritualActive = false;
        
        // Cancel all tasks
        if (ritualTask != null && !ritualTask.isCancelled()) {
            ritualTask.cancel();
        }
        if (particleTask != null && !particleTask.isCancelled()) {
            particleTask.cancel();
        }
        if (broadcastTask != null && !broadcastTask.isCancelled()) {
            broadcastTask.cancel();
        }
        if (bossBarTask != null && !bossBarTask.isCancelled()) {
            bossBarTask.cancel();
        }
        
        // Remove boss bar
        if (ritualBossBar != null) {
            ritualBossBar.removeAll();
            ritualBossBar = null;
        }
        
        // Remove beacon protection
        if (ritualLocation != null) {
            Block beacon = ritualLocation.getBlock();
            if (beacon.hasMetadata("ritual_protected")) {
                beacon.removeMetadata("ritual_protected", plugin);
            }
            
            // Remove iron platform protection
            protectIronPlatform(ritualLocation, false);
        }
        
        ritualLocation = null;
        remainingTime = 0;
    }
    
    private void createBossBar() {
        ritualBossBar = Bukkit.createBossBar(
            "§5⚔️ Mace Ritual ⚔️", 
            BarColor.PURPLE, 
            BarStyle.SEGMENTED_10
        );
        
        // Add all online players to the boss bar
        for (Player player : Bukkit.getOnlinePlayers()) {
            ritualBossBar.addPlayer(player);
        }
        
        ritualBossBar.setVisible(true);
        ritualBossBar.setProgress(1.0); // Start at 100%
    }
    
    private void startBossBarUpdater() {
        bossBarTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (!ritualActive || ritualBossBar == null) {
                    cancel();
                    return;
                }
                
                // Update progress (remaining time / total time)
                double progress = Math.max(0.0, (double) remainingTime / totalTime);
                ritualBossBar.setProgress(progress);
                
                // Update title with time remaining
                int minutes = remainingTime / 60;
                int seconds = remainingTime % 60;
                String timeText = String.format("%02d:%02d", minutes, seconds);
                
                // Change color based on remaining time
                BarColor color;
                if (progress > 0.66) {
                    color = BarColor.GREEN;
                } else if (progress > 0.33) {
                    color = BarColor.YELLOW;
                } else {
                    color = BarColor.RED;
                }
                
                ritualBossBar.setColor(color);
                ritualBossBar.setTitle("§5⚔️ Mace Ritual - " + timeText + " ⚔️");
                
                // Add new players who joined during ritual
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (!ritualBossBar.getPlayers().contains(player)) {
                        ritualBossBar.addPlayer(player);
                    }
                }
                
                // Decrement time
                remainingTime--;
                
                // Check if ritual should complete
                if (remainingTime <= 0) {
                    cancel();
                    completeRitual();
                }
            }
        }.runTaskTimer(plugin, 20L, 20L); // Run every second (20 ticks)
    }
    
    public int getRemainingTime() {
        return remainingTime;
    }
    
    public boolean reduceTime(int seconds) {
        if (!ritualActive || remainingTime <= 0) {
            return false;
        }
        
        remainingTime -= seconds;
        
        // If time goes to 0 or below, complete the ritual immediately
        if (remainingTime <= 0) {
            remainingTime = 0;
            
            // Cancel the boss bar task and complete ritual
            if (bossBarTask != null && !bossBarTask.isCancelled()) {
                bossBarTask.cancel();
            }
            
            // Complete ritual immediately
            completeRitual();
        }
        
        return true;
    }
    
    private void protectIronPlatform(Location beaconLocation, boolean protect) {
        // Get the center of the 3x3 iron platform (one block below the beacon)
        Block baseCenter = beaconLocation.getBlock().getRelative(0, -1, 0);
        
        // Apply or remove protection to all 9 blocks in the 3x3 platform
        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                Block platformBlock = baseCenter.getRelative(x, 0, z);
                
                if (protect) {
                    // Add protection metadata to iron blocks
                    if (platformBlock.getType() == Material.IRON_BLOCK) {
                        platformBlock.setMetadata("ritual_platform_protected", new FixedMetadataValue(plugin, true));
                    }
                } else {
                    // Remove protection metadata
                    if (platformBlock.hasMetadata("ritual_platform_protected")) {
                        platformBlock.removeMetadata("ritual_platform_protected", plugin);
                    }
                }
            }
        }
        
        if (protect) {
            plugin.getLogger().info("Protected 3x3 iron platform at ritual location: " + beaconLocation);
        } else {
            plugin.getLogger().info("Removed protection from 3x3 iron platform at ritual location: " + beaconLocation);
        }
    }
}