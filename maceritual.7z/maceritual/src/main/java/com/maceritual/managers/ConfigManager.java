package com.maceritual.managers;

import com.maceritual.MaceRitualPlugin;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.Arrays;
import java.util.List;

public class ConfigManager {

    private final MaceRitualPlugin plugin;
    private FileConfiguration config;

    public ConfigManager(MaceRitualPlugin plugin) {
        this.plugin = plugin;
        loadConfig();
    }

    public void loadConfig() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        config = plugin.getConfig();

        // Set default values if not present
        if (!config.contains("ritual_duration")) {
            config.set("ritual_duration", 1800); // 30 minutes
        }
        if (!config.contains("broadcast_interval")) {
            config.set("broadcast_interval", 300); // 5 minutes
        }
        if (!config.contains("allow_mace_drop_on_death")) {
            config.set("allow_mace_drop_on_death", true);
        }
        if (!config.contains("only_one_mace_allowed")) {
            config.set("only_one_mace_allowed", true);
        }
        if (!config.contains("beacon_block_name")) {
            config.set("beacon_block_name", "§5Mace Ritual");
        }
        if (!config.contains("recipe.shaped")) {
            config.set("recipe.shaped", false);
        }
        if (!config.contains("recipe.ingredients")) {
            config.set("recipe.ingredients", Arrays.asList(
                    "NETHERITE_INGOT",
                    "ECHO_SHARD",
                    "ECHO_SHARD",
                    "TOTEM_OF_UNDYING",
                    "DRAGON_BREATH"));
        }

        // One-time system configuration
        if (!config.contains("one_time_system.broken_mace_crafted")) {
            config.set("one_time_system.broken_mace_crafted", false);
        }
        if (!config.contains("one_time_system.ritual_completed")) {
            config.set("one_time_system.ritual_completed", false);
        }
        if (!config.contains("one_time_system.enabled")) {
            config.set("one_time_system.enabled", true);
        }

        // Spawn radius restriction configuration
        if (!config.contains("spawn_radius.enabled")) {
            config.set("spawn_radius.enabled", true);
        }
        if (!config.contains("spawn_radius.max_distance")) {
            config.set("spawn_radius.max_distance", 5000);
        }
        if (!config.contains("spawn_radius.use_world_spawn")) {
            config.set("spawn_radius.use_world_spawn", true);
        }

        plugin.saveConfig();

        // Log one-time system status on startup
        logOneTimeSystemStatus();
    }

    private void logOneTimeSystemStatus() {
        boolean enabled = isOneTimeSystemEnabled();
        boolean maceCrafted = isBrokenMaceCrafted();
        boolean ritualCompleted = isRitualCompleted();

        plugin.getLogger().info("=== One-Time System Status ===");
        plugin.getLogger().info("System Enabled: " + enabled);
        plugin.getLogger().info("Broken Mace Crafted: " + maceCrafted);
        plugin.getLogger().info("Ritual Completed: " + ritualCompleted);

        if (enabled) {
            if (maceCrafted && ritualCompleted) {
                plugin.getLogger().info("⚠️ BOTH crafting and ritual have been used - system fully locked");
            } else if (maceCrafted) {
                plugin.getLogger().info("⚠️ Broken mace has been crafted - crafting locked, ritual available");
            } else if (ritualCompleted) {
                plugin.getLogger().info("⚠️ Ritual has been completed - ritual locked, crafting available");
            } else {
                plugin.getLogger().info("✓ Both crafting and ritual are available");
            }
        } else {
            plugin.getLogger().info("One-time system is disabled - no restrictions apply");
        }
        plugin.getLogger().info("===============================");
    }

    public void reloadConfig() {
        loadConfig();
    }

    public int getRitualDuration() {
        return config.getInt("ritual_duration", 1800);
    }

    public int getBroadcastInterval() {
        return config.getInt("broadcast_interval", 300);
    }

    public boolean allowMaceDropOnDeath() {
        return config.getBoolean("allow_mace_drop_on_death", true);
    }

    public boolean onlyOneMaceAllowed() {
        return config.getBoolean("only_one_mace_allowed", true);
    }

    public String getBeaconBlockName() {
        return config.getString("beacon_block_name", "§5Mace Ritual");
    }

    public boolean isRecipeShaped() {
        return config.getBoolean("recipe.shaped", false);
    }

    public List<String> getRecipeIngredients() {
        return config.getStringList("recipe.ingredients");
    }

    public void setRecipeIngredients(List<String> ingredients) {
        config.set("recipe.ingredients", ingredients);
        plugin.saveConfig();
    }

    public void setRecipeShaped(boolean shaped) {
        config.set("recipe.shaped", shaped);
        plugin.saveConfig();
    }

    // One-time system methods
    public boolean isOneTimeSystemEnabled() {
        return config.getBoolean("one_time_system.enabled", true);
    }

    public boolean isBrokenMaceCrafted() {
        return config.getBoolean("one_time_system.broken_mace_crafted", false);
    }

    public boolean isRitualCompleted() {
        return config.getBoolean("one_time_system.ritual_completed", false);
    }

    public void setBrokenMaceCrafted(boolean crafted) {
        config.set("one_time_system.broken_mace_crafted", crafted);
        plugin.saveConfig();
        plugin.getLogger().info("One-time system: Broken mace crafted status set to " + crafted);
    }

    public void setRitualCompleted(boolean completed) {
        config.set("one_time_system.ritual_completed", completed);
        plugin.saveConfig();
        plugin.getLogger().info("One-time system: Ritual completed status set to " + completed);
    }

    public void setOneTimeSystemEnabled(boolean enabled) {
        config.set("one_time_system.enabled", enabled);
        plugin.saveConfig();
    }

    public void resetOneTimeSystem() {
        config.set("one_time_system.broken_mace_crafted", false);
        config.set("one_time_system.ritual_completed", false);
        plugin.saveConfig();
    }

    // Spawn radius restriction methods
    public boolean isSpawnRadiusEnabled() {
        return config.getBoolean("spawn_radius.enabled", true);
    }

    public int getSpawnRadiusMaxDistance() {
        return config.getInt("spawn_radius.max_distance", 5000);
    }

    public boolean useWorldSpawn() {
        return config.getBoolean("spawn_radius.use_world_spawn", true);
    }
}