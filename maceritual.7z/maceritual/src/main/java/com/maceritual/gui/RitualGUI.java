package com.maceritual.gui;

import com.maceritual.MaceRitualPlugin;
import com.maceritual.utils.ItemUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class RitualGUI implements Listener {
    
    private final MaceRitualPlugin plugin;
    private final Player player;
    private final Inventory gui;
    private final org.bukkit.Location beaconLocation;
    
    public RitualGUI(MaceRitualPlugin plugin, Player player, org.bukkit.Location beaconLocation) {
        this.plugin = plugin;
        this.player = player;
        this.beaconLocation = beaconLocation;
        this.gui = Bukkit.createInventory(null, 27, "§5Mace Ritual");
        
        setupGUI();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }
    
    private void setupGUI() {
        // Fill with decorative glass
        ItemStack glass = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta glassMeta = glass.getItemMeta();
        if (glassMeta != null) {
            glassMeta.setDisplayName(" ");
            glass.setItemMeta(glassMeta);
        }
        
        for (int i = 0; i < 27; i++) {
            gui.setItem(i, glass);
        }
        
        // Central slot for Broken Mace (slot 13)
        gui.setItem(13, null);
        
        // Start Ritual button (slot 22)
        ItemStack startButton = new ItemStack(Material.EMERALD);
        ItemMeta buttonMeta = startButton.getItemMeta();
        if (buttonMeta != null) {
            buttonMeta.setDisplayName("§aStart Ritual");
            buttonMeta.setLore(Arrays.asList(
                "§7Place a Broken Mace in the slot above",
                "§7to begin the ritual process."
            ));
            startButton.setItemMeta(buttonMeta);
        }
        gui.setItem(22, startButton);
    }
    
    public void open() {
        player.openInventory(gui);
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!event.getWhoClicked().equals(player)) return;
        
        // Check if clicking in the GUI inventory
        if (event.getClickedInventory() != null && event.getClickedInventory().equals(gui)) {
            int slot = event.getSlot();
            
            // Handle Start Ritual button (slot 22)
            if (slot == 22) {
                event.setCancelled(true);
                
                ItemStack brokenMace = gui.getItem(13);
                if (brokenMace == null || !ItemUtils.isBrokenMace(brokenMace)) {
                    player.sendMessage("§cYou must place a Broken Mace in the ritual slot first!");
                    return;
                }
                
                // Start the ritual
                if (plugin.getRitualManager().startRitual(beaconLocation, player)) {
                    // Remove the Broken Mace from the GUI
                    gui.setItem(13, null);
                    player.closeInventory();
                    player.sendMessage("§aThe ritual has begun! The mace has been consumed.");
                }
                return;
            }
            
            // Handle central slot (13) - allow placing items but validate after
            if (slot == 13) {
                // Don't cancel - allow the placement
                
                // Check what was placed after a short delay
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    ItemStack placedItem = gui.getItem(13);
                    if (placedItem != null && placedItem.getType() != Material.AIR) {
                        if (!ItemUtils.isBrokenMace(placedItem)) {
                            // Remove invalid item and return to player
                            gui.setItem(13, null);
                            player.getInventory().addItem(placedItem);
                            player.sendMessage("§cOnly a Broken Mace can be placed here!");
                            player.sendMessage("§7Craft a Broken Mace using the custom recipe first.");
                        } else {
                            player.sendMessage("§aBroken Mace placed! Click 'Start Ritual' to begin.");
                        }
                    }
                }, 1L);
                
                return; // Allow the placement
            }
            
            // Block all other interactions (glass panes)
            event.setCancelled(true);
        }
        // If clicking in player inventory - always allow
    }
    
    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!event.getWhoClicked().equals(player)) return;
        if (!event.getInventory().equals(gui)) return;
        
        // Check if dragging to protected slots
        for (int slot : event.getRawSlots()) {
            if (slot < gui.getSize()) { // If dragging to GUI inventory
                if (slot == 22) { // Start button
                    event.setCancelled(true);
                    return;
                }
                // Check if dragging to glass pane
                if (slot != 13 && gui.getItem(slot) != null && gui.getItem(slot).getType() == Material.BLACK_STAINED_GLASS_PANE) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
        
        // If dragging to slot 13, validate after
        if (event.getRawSlots().contains(13)) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                ItemStack placedItem = gui.getItem(13);
                if (placedItem != null && placedItem.getType() != Material.AIR) {
                    if (!ItemUtils.isBrokenMace(placedItem)) {
                        // Remove invalid item and return to player
                        gui.setItem(13, null);
                        player.getInventory().addItem(placedItem);
                        player.sendMessage("§cOnly a Broken Mace can be placed here!");
                        player.sendMessage("§7Craft a Broken Mace using the custom recipe first.");
                    } else {
                        player.sendMessage("§aBroken Mace placed! Click 'Start Ritual' to begin.");
                    }
                }
            }, 1L);
        }
    }
    
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!event.getInventory().equals(gui)) return;
        if (!event.getPlayer().equals(player)) return;
        
        // Return any items in the central slot
        ItemStack item = gui.getItem(13);
        if (item != null && !item.getType().equals(Material.AIR)) {
            player.getInventory().addItem(item);
        }
        
        // Unregister this listener
        InventoryClickEvent.getHandlerList().unregister(this);
        InventoryCloseEvent.getHandlerList().unregister(this);
    }
}