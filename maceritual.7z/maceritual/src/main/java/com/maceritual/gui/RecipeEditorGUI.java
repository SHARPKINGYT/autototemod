package com.maceritual.gui;

import com.maceritual.MaceRitualPlugin;
import com.maceritual.utils.ItemUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RecipeEditorGUI implements Listener {
    
    private final MaceRitualPlugin plugin;
    private final Player player;
    private final Inventory gui;
    private boolean isShapedRecipe;
    
    // Slot mappings for 54-slot inventory
    private final int[] CRAFTING_SLOTS = {10, 11, 12, 19, 20, 21, 28, 29, 30}; // 3x3 grid
    private final int RESULT_SLOT = 24; // Result slot (center-right)
    private final int TYPE_TOGGLE_SLOT = 4;
    private final int SAVE_SLOT = 48;
    private final int CLEAR_SLOT = 49;
    private final int BACK_SLOT = 50;
    
    public RecipeEditorGUI(MaceRitualPlugin plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
        this.gui = Bukkit.createInventory(null, 54, "§6Broken Mace Recipe Editor");
        this.isShapedRecipe = plugin.getConfigManager().isRecipeShaped();
        
        setupGUI();
        loadCurrentRecipe();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }
    
    private void setupGUI() {
        // Clear inventory
        gui.clear();
        
        // Fill with glass panes
        ItemStack glass = new ItemStack(Material.LIGHT_GRAY_STAINED_GLASS_PANE);
        ItemMeta glassMeta = glass.getItemMeta();
        if (glassMeta != null) {
            glassMeta.setDisplayName(" ");
            glass.setItemMeta(glassMeta);
        }
        
        // Fill entire inventory with glass first
        for (int i = 0; i < 54; i++) {
            gui.setItem(i, glass);
        }
        
        // Clear crafting slots and result slot
        for (int slot : CRAFTING_SLOTS) {
            gui.setItem(slot, null);
        }
        gui.setItem(RESULT_SLOT, null);
        
        // Show result item (Broken Mace)
        gui.setItem(RESULT_SLOT, ItemUtils.createBrokenMace());
        
        // Recipe type toggle button
        setupTypeToggleButton();
        
        // Control buttons
        setupControlButtons();
        
        // Add instruction labels
        setupInstructionLabels();
    }
    
    private void loadCurrentRecipe() {
        List<String> ingredients = plugin.getConfigManager().getRecipeIngredients();
        
        // Load ingredients into crafting grid
        for (int i = 0; i < Math.min(ingredients.size(), 9); i++) {
            try {
                Material material = Material.valueOf(ingredients.get(i).toUpperCase());
                ItemStack item = new ItemStack(material);
                gui.setItem(CRAFTING_SLOTS[i], item);
            } catch (IllegalArgumentException e) {
                // Skip invalid materials
                plugin.getLogger().warning("Invalid material in recipe: " + ingredients.get(i));
            }
        }
    }
    
    private void setupTypeToggleButton() {
        ItemStack typeButton = new ItemStack(isShapedRecipe ? Material.CRAFTING_TABLE : Material.DROPPER);
        ItemMeta typeMeta = typeButton.getItemMeta();
        if (typeMeta != null) {
            typeMeta.setDisplayName("§eRecipe Type: " + (isShapedRecipe ? "§aShaped" : "§bShapeless"));
            typeMeta.setLore(Arrays.asList(
                "§7Click to toggle recipe type"
            ));
            typeButton.setItemMeta(typeMeta);
        }
        gui.setItem(TYPE_TOGGLE_SLOT, typeButton);
    }
    
    private void setupControlButtons() {
        // Save button
        ItemStack saveButton = new ItemStack(Material.EMERALD);
        ItemMeta saveMeta = saveButton.getItemMeta();
        if (saveMeta != null) {
            saveMeta.setDisplayName("§a✓ Save Recipe");
            saveMeta.setLore(Arrays.asList(
                "§7Save changes and update recipe"
            ));
            saveButton.setItemMeta(saveMeta);
        }
        gui.setItem(SAVE_SLOT, saveButton);
        
        // Clear all button
        ItemStack clearButton = new ItemStack(Material.RED_CONCRETE);
        ItemMeta clearMeta = clearButton.getItemMeta();
        if (clearMeta != null) {
            clearMeta.setDisplayName("§c✗ Clear All");
            clearMeta.setLore(Arrays.asList(
                "§7Remove all items from recipe"
            ));
            clearButton.setItemMeta(clearMeta);
        }
        gui.setItem(CLEAR_SLOT, clearButton);
        
        // Back button
        ItemStack backButton = new ItemStack(Material.ARROW);
        ItemMeta backMeta = backButton.getItemMeta();
        if (backMeta != null) {
            backMeta.setDisplayName("§7← Back");
            backMeta.setLore(Arrays.asList(
                "§7Close without saving changes"
            ));
            backButton.setItemMeta(backMeta);
        }
        gui.setItem(BACK_SLOT, backButton);
    }
    
    private void setupInstructionLabels() {
        // Instructions
        ItemStack instructions = new ItemStack(Material.BOOK);
        ItemMeta instrMeta = instructions.getItemMeta();
        if (instrMeta != null) {
            instrMeta.setDisplayName("§6Recipe Editor Instructions");
            instrMeta.setLore(Arrays.asList(
                "§71. Drag items from your inventory",
                "§72. Place them in the 3x3 crafting grid",
                "§73. Click Save to apply changes"
            ));
            instructions.setItemMeta(instrMeta);
        }
        gui.setItem(0, instructions);
    }
    
    public void open() {
        player.openInventory(gui);
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!event.getWhoClicked().equals(player)) return;
        
        // Check if clicking in the GUI inventory
        if (event.getClickedInventory() != null && event.getClickedInventory().equals(gui)) {
            int slot = event.getSlot();
            
            // Handle button clicks ONLY
            if (slot == TYPE_TOGGLE_SLOT) {
                event.setCancelled(true);
                isShapedRecipe = !isShapedRecipe;
                setupTypeToggleButton();
                player.sendMessage("§eRecipe type: " + (isShapedRecipe ? "§aShaped" : "§bShapeless"));
            } else if (slot == SAVE_SLOT) {
                event.setCancelled(true);
                saveRecipe();
            } else if (slot == CLEAR_SLOT) {
                event.setCancelled(true);
                clearAllItems();
            } else if (slot == BACK_SLOT) {
                event.setCancelled(true);
                player.closeInventory();
                player.sendMessage("§7Recipe editor closed.");
            } else if (slot == RESULT_SLOT || slot == 0) {
                // Block result slot and instruction book
                event.setCancelled(true);
            } else if (gui.getItem(slot) != null && gui.getItem(slot).getType() == Material.LIGHT_GRAY_STAINED_GLASS_PANE) {
                // Block glass panes
                event.setCancelled(true);
            }
            // For crafting slots - allow normal interaction
        }
        // If clicking in player inventory - always allow
    }
    
    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!event.getWhoClicked().equals(player)) return;
        if (!event.getInventory().equals(gui)) return;
        
        // Check if dragging to protected slots
        for (int slot : event.getRawSlots()) {
            if (slot < gui.getSize()) { // If dragging to GUI inventory
                if (slot == TYPE_TOGGLE_SLOT || slot == SAVE_SLOT || slot == CLEAR_SLOT || 
                    slot == BACK_SLOT || slot == RESULT_SLOT || slot == 0) {
                    event.setCancelled(true);
                    return;
                }
                // Check if dragging to glass pane
                if (gui.getItem(slot) != null && gui.getItem(slot).getType() == Material.LIGHT_GRAY_STAINED_GLASS_PANE) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
        // Allow dragging to crafting slots
    }
    
    private void clearAllItems() {
        // Clear all crafting slots
        for (int slot : CRAFTING_SLOTS) {
            ItemStack item = gui.getItem(slot);
            if (item != null && item.getType() != Material.AIR) {
                // Try to return item to player inventory
                if (player.getInventory().firstEmpty() != -1) {
                    player.getInventory().addItem(item);
                } else {
                    player.getWorld().dropItemNaturally(player.getLocation(), item);
                }
            }
            gui.setItem(slot, null);
        }
        
        player.sendMessage("§cAll items cleared!");
        player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_LAVA_EXTINGUISH, 0.5f, 1.0f);
    }
    
    private void saveRecipe() {
        // Get items from crafting grid
        List<String> ingredients = new ArrayList<>();
        
        for (int i = 0; i < CRAFTING_SLOTS.length; i++) {
            ItemStack item = gui.getItem(CRAFTING_SLOTS[i]);
            if (item != null && item.getType() != Material.AIR) {
                ingredients.add(item.getType().name());
            }
        }
        
        if (ingredients.isEmpty()) {
            player.sendMessage("§cCannot save empty recipe! Add at least one ingredient.");
            player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_ANVIL_LAND, 0.5f, 0.5f);
            return;
        }
        
        // Save to config
        plugin.getConfigManager().setRecipeIngredients(ingredients);
        plugin.getConfigManager().setRecipeShaped(isShapedRecipe);
        
        // Reload recipe
        plugin.getRecipeManager().reloadRecipe();
        
        player.closeInventory();
        player.sendMessage("§a✓ Recipe saved successfully!");
        player.sendMessage("§7Type: " + (isShapedRecipe ? "Shaped" : "Shapeless"));
        player.sendMessage("§7Ingredients: " + ingredients.size());
        
        // Play success sound
        player.playSound(player.getLocation(), org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
    }
    
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!event.getInventory().equals(gui)) return;
        if (!event.getPlayer().equals(player)) return;
        
        // Unregister this listener
        InventoryClickEvent.getHandlerList().unregister(this);
        InventoryCloseEvent.getHandlerList().unregister(this);
    }
}