package com.maceritual.commands;

import com.maceritual.MaceRitualPlugin;
import com.maceritual.gui.RecipeEditorGUI;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MaceRitualCommand implements CommandExecutor, TabCompleter {
    
    private final MaceRitualPlugin plugin;
    
    public MaceRitualCommand(MaceRitualPlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("maceritual.admin")) {
            sender.sendMessage("§cYou don't have permission to use this command!");
            return true;
        }
        
        if (args.length == 0) {
            sender.sendMessage("§cUsage: /maceritual <reload|recipe|reducetime|reset>");
            return true;
        }
        
        switch (args[0].toLowerCase()) {
            case "reload":
                plugin.getConfigManager().reloadConfig();
                plugin.getRecipeManager().reloadRecipe();
                sender.sendMessage("§aConfiguration and recipes reloaded!");
                break;
                
            case "recipe":
                if (!(sender instanceof Player)) {
                    sender.sendMessage("§cOnly players can use the recipe editor GUI!");
                    sender.sendMessage("§7Use console commands: /maceritual recipe add/remove/type");
                    return true;
                }
                
                Player player = (Player) sender;
                if (args.length == 1) {
                    // Open GUI editor
                    RecipeEditorGUI gui = new RecipeEditorGUI(plugin, player);
                    gui.open();
                    player.sendMessage("§aOpening recipe editor...");
                } else {
                    // Handle legacy text commands for console compatibility
                    handleRecipeEdit(sender, args);
                }
                break;
                
            case "reducetime":
                if (args.length < 2) {
                    sender.sendMessage("§cUsage: /maceritual reducetime <time>");
                    sender.sendMessage("§7Examples: 1min, 30sec, 5m, 10s");
                    return true;
                }
                
                if (!plugin.getRitualManager().isRitualActive()) {
                    sender.sendMessage("§cNo ritual is currently active!");
                    return true;
                }
                
                handleReduceTime(sender, args[1]);
                break;
                
            case "reset":
                if (args.length < 2) {
                    sender.sendMessage("§cUsage: /maceritual reset <all|crafting|ritual|status>");
                    sender.sendMessage("§7all - Reset both crafting and ritual counters");
                    sender.sendMessage("§7crafting - Reset broken mace crafting counter");
                    sender.sendMessage("§7ritual - Reset ritual completion counter");
                    sender.sendMessage("§7status - Show current one-time system status");
                    return true;
                }
                
                handleReset(sender, args[1]);
                break;
                
            default:
                sender.sendMessage("§cUnknown subcommand. Usage: /maceritual <reload|recipe|reducetime|reset>");
                break;
        }
        
        return true;
    }
    
    private void showCurrentRecipe(CommandSender sender) {
        List<String> ingredients = plugin.getConfigManager().getRecipeIngredients();
        boolean shaped = plugin.getConfigManager().isRecipeShaped();
        
        sender.sendMessage("§6=== Current Broken Mace Recipe ===");
        sender.sendMessage("§eType: " + (shaped ? "Shaped" : "Shapeless"));
        sender.sendMessage("§eIngredients:");
        
        for (int i = 0; i < ingredients.size(); i++) {
            sender.sendMessage("§7  " + (i + 1) + ". " + ingredients.get(i));
        }
        
        sender.sendMessage("§7Use '/maceritual recipe add <material>' to add ingredients");
        sender.sendMessage("§7Use '/maceritual recipe remove <index>' to remove ingredients");
        sender.sendMessage("§7Use '/maceritual recipe type <shaped|shapeless>' to change type");
    }
    
    private void handleRecipeEdit(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("§cUsage: /maceritual recipe <add|remove|type> <value>");
            return;
        }
        
        switch (args[1].toLowerCase()) {
            case "add":
                String material = args[2].toUpperCase();
                try {
                    Material.valueOf(material);
                    List<String> ingredients = plugin.getConfigManager().getRecipeIngredients();
                    ingredients.add(material);
                    plugin.getConfigManager().setRecipeIngredients(ingredients);
                    plugin.getRecipeManager().reloadRecipe();
                    sender.sendMessage("§aAdded " + material + " to recipe!");
                } catch (IllegalArgumentException e) {
                    sender.sendMessage("§cInvalid material: " + material);
                }
                break;
                
            case "remove":
                try {
                    int index = Integer.parseInt(args[2]) - 1;
                    List<String> ingredients = plugin.getConfigManager().getRecipeIngredients();
                    if (index >= 0 && index < ingredients.size()) {
                        String removed = ingredients.remove(index);
                        plugin.getConfigManager().setRecipeIngredients(ingredients);
                        plugin.getRecipeManager().reloadRecipe();
                        sender.sendMessage("§aRemoved " + removed + " from recipe!");
                    } else {
                        sender.sendMessage("§cInvalid index! Use 1-" + ingredients.size());
                    }
                } catch (NumberFormatException e) {
                    sender.sendMessage("§cInvalid number: " + args[2]);
                }
                break;
                
            case "type":
                String type = args[2].toLowerCase();
                if (type.equals("shaped") || type.equals("shapeless")) {
                    boolean shaped = type.equals("shaped");
                    plugin.getConfigManager().setRecipeShaped(shaped);
                    plugin.getRecipeManager().reloadRecipe();
                    sender.sendMessage("§aRecipe type changed to " + type + "!");
                } else {
                    sender.sendMessage("§cInvalid type! Use 'shaped' or 'shapeless'");
                }
                break;
                
            default:
                sender.sendMessage("§cUsage: /maceritual recipe <add|remove|type> <value>");
                break;
        }
    }
    
    private void handleReduceTime(CommandSender sender, String timeString) {
        try {
            int seconds = parseTimeString(timeString);
            if (seconds <= 0) {
                sender.sendMessage("§cInvalid time! Must be greater than 0.");
                return;
            }
            
            boolean success = plugin.getRitualManager().reduceTime(seconds);
            if (success) {
                sender.sendMessage("§aReduced ritual time by " + formatTime(seconds) + "!");
                sender.sendMessage("§7Remaining time: " + formatTime(plugin.getRitualManager().getRemainingTime()));
            } else {
                sender.sendMessage("§cCould not reduce time. Ritual may have ended or time is already at minimum.");
            }
        } catch (IllegalArgumentException e) {
            sender.sendMessage("§cInvalid time format! Examples: 1min, 30sec, 5m, 10s");
        }
    }
    
    private int parseTimeString(String timeString) throws IllegalArgumentException {
        timeString = timeString.toLowerCase().trim();
        
        if (timeString.endsWith("min") || timeString.endsWith("m")) {
            String numberPart = timeString.replaceAll("[^0-9]", "");
            return Integer.parseInt(numberPart) * 60;
        } else if (timeString.endsWith("sec") || timeString.endsWith("s")) {
            String numberPart = timeString.replaceAll("[^0-9]", "");
            return Integer.parseInt(numberPart);
        } else {
            // Try to parse as just a number (assume seconds)
            return Integer.parseInt(timeString);
        }
    }
    
    private String formatTime(int seconds) {
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        
        if (minutes > 0) {
            return minutes + "m " + remainingSeconds + "s";
        } else {
            return remainingSeconds + "s";
        }
    }
    
    private void handleReset(CommandSender sender, String resetType) {
        switch (resetType.toLowerCase()) {
            case "all":
                plugin.getConfigManager().resetOneTimeSystem();
                sender.sendMessage("§a✓ One-time system completely reset!");
                sender.sendMessage("§7• Broken mace can be crafted again");
                sender.sendMessage("§7• Ritual can be performed again");
                plugin.getLogger().info("One-time system reset by: " + sender.getName());
                break;
                
            case "crafting":
                plugin.getConfigManager().setBrokenMaceCrafted(false);
                sender.sendMessage("§a✓ Broken mace crafting counter reset!");
                sender.sendMessage("§7Players can now craft the broken mace again.");
                plugin.getLogger().info("Broken mace crafting reset by: " + sender.getName());
                break;
                
            case "ritual":
                plugin.getConfigManager().setRitualCompleted(false);
                sender.sendMessage("§a✓ Ritual completion counter reset!");
                sender.sendMessage("§7The ritual can now be performed again.");
                plugin.getLogger().info("Ritual completion reset by: " + sender.getName());
                break;
                
            case "status":
                showOneTimeSystemStatus(sender);
                break;
                
            default:
                sender.sendMessage("§cInvalid reset type! Use: all, crafting, ritual, or status");
                break;
        }
    }
    
    private void showOneTimeSystemStatus(CommandSender sender) {
        boolean enabled = plugin.getConfigManager().isOneTimeSystemEnabled();
        boolean maceCrafted = plugin.getConfigManager().isBrokenMaceCrafted();
        boolean ritualCompleted = plugin.getConfigManager().isRitualCompleted();
        
        sender.sendMessage("§6=== One-Time System Status ===");
        sender.sendMessage("§eSystem Enabled: " + (enabled ? "§aYes" : "§cNo"));
        sender.sendMessage("§eBroken Mace Crafted: " + (maceCrafted ? "§cYes" : "§aNo"));
        sender.sendMessage("§eRitual Completed: " + (ritualCompleted ? "§cYes" : "§aNo"));
        
        if (enabled) {
            if (!maceCrafted && !ritualCompleted) {
                sender.sendMessage("§a✓ Both crafting and ritual are available!");
            } else if (maceCrafted && !ritualCompleted) {
                sender.sendMessage("§e⚠ Broken mace crafted, ritual still available");
            } else if (!maceCrafted && ritualCompleted) {
                sender.sendMessage("§c✗ Ritual completed, but mace crafting available (unusual state)");
            } else {
                sender.sendMessage("§c✗ Both crafting and ritual have been used");
            }
        } else {
            sender.sendMessage("§7One-time system is disabled - no restrictions apply");
        }
    }
    
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Arrays.asList("reload", "recipe", "reducetime", "reset");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("recipe")) {
            return Arrays.asList("add", "remove", "type");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("reducetime")) {
            return Arrays.asList("1min", "5min", "10min", "30sec", "1m", "5m", "10s", "30s");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("reset")) {
            return Arrays.asList("all", "crafting", "ritual", "status");
        } else if (args.length == 3 && args[0].equalsIgnoreCase("recipe")) {
            if (args[1].equalsIgnoreCase("add")) {
                return Arrays.stream(Material.values())
                    .map(Material::name)
                    .filter(name -> name.toLowerCase().startsWith(args[2].toLowerCase()))
                    .collect(Collectors.toList());
            } else if (args[1].equalsIgnoreCase("type")) {
                return Arrays.asList("shaped", "shapeless");
            }
        }
        return null;
    }
}