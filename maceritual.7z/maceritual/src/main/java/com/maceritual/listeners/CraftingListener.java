package com.maceritual.listeners;

import com.maceritual.MaceRitualPlugin;
import com.maceritual.utils.ItemUtils;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.inventory.ItemStack;

public class CraftingListener implements Listener {

    private final MaceRitualPlugin plugin;

    public CraftingListener(MaceRitualPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPrepareItemCraft(PrepareItemCraftEvent event) {
        ItemStack result = event.getInventory().getResult();

        // Block vanilla mace crafting
        if (result != null && result.getType() == Material.MACE) {
            // Allow only our custom maces
            if (!ItemUtils.isBrokenMace(result) && !ItemUtils.isTrueMace(result)) {
                event.getInventory().setResult(null);
            } else if (ItemUtils.isBrokenMace(result)) {
                // Check one-time system for broken mace
                if (plugin.getConfigManager().isOneTimeSystemEnabled() && 
                    plugin.getConfigManager().isBrokenMaceCrafted()) {
                    event.getInventory().setResult(null);
                }
            }
        }
    }

    @EventHandler
    public void onCraftItem(CraftItemEvent event) {
        ItemStack result = event.getCurrentItem();

        // Block vanilla mace crafting
        if (result != null && result.getType() == Material.MACE) {
            // Allow only our custom maces
            if (!ItemUtils.isBrokenMace(result) && !ItemUtils.isTrueMace(result)) {
                event.setCancelled(true);
                if (event.getWhoClicked() instanceof Player) {
                    Player player = (Player) event.getWhoClicked();
                    player.sendMessage("§cVanilla mace crafting is disabled! Use the ritual system instead.");
                }
            } else if (ItemUtils.isBrokenMace(result)) {
                // Check one-time system for broken mace
                if (plugin.getConfigManager().isOneTimeSystemEnabled()) {
                    if (plugin.getConfigManager().isBrokenMaceCrafted()) {
                        event.setCancelled(true);
                        if (event.getWhoClicked() instanceof Player) {
                            Player player = (Player) event.getWhoClicked();
                            player.sendMessage("§c✗ The Broken Mace has already been crafted once!");
                            player.sendMessage("§7Only one Broken Mace can ever be created on this server.");
                            player.sendMessage("§7Contact an admin if you need to reset the system.");
                        }
                    } else {
                        // Mark broken mace as crafted
                        plugin.getConfigManager().setBrokenMaceCrafted(true);
                        if (event.getWhoClicked() instanceof Player) {
                            Player player = (Player) event.getWhoClicked();
                            player.sendMessage("§6✓ You have crafted the one and only Broken Mace!");
                            player.sendMessage("§7This is the only Broken Mace that will ever exist on this server.");
                        }
                        plugin.getLogger().info("Broken Mace crafted by: " + event.getWhoClicked().getName());
                    }
                }
            }
        }
    }
}