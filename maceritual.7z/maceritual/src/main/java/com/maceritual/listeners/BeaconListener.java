package com.maceritual.listeners;

import com.maceritual.MaceRitualPlugin;
import com.maceritual.gui.RitualGUI;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;

public class BeaconListener implements Listener {

    private final MaceRitualPlugin plugin;

    public BeaconListener(MaceRitualPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK)
            return;

        Block block = event.getClickedBlock();
        if (block == null || block.getType() != Material.BEACON)
            return;

        Player player = event.getPlayer();

        // Check if this beacon is marked as a ritual beacon
        if (isRitualBeacon(block)) {
            event.setCancelled(true);

            if (!block.getWorld().getEnvironment().equals(org.bukkit.World.Environment.NORMAL)) {
                player.sendMessage("§cRituals can only be performed in the Overworld!");
                return;
            }

            if (plugin.getRitualManager().isRitualActive()) {
                player.sendMessage("§cA ritual is already in progress!");
                return;
            }

            RitualGUI gui = new RitualGUI(plugin, player, block.getLocation());
            gui.open();
        }
        // If not a ritual beacon, let vanilla behavior continue (don't cancel event)
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        if (event.getBlock().getType() != Material.BEACON)
            return;

        ItemStack item = event.getItemInHand();
        if (item.hasItemMeta()) {
            ItemMeta meta = item.getItemMeta();
            String expectedName = plugin.getConfigManager().getBeaconBlockName();

            plugin.getLogger().info("Beacon placed - Expected: '" + expectedName + "', Actual: '" +
                    (meta.hasDisplayName() ? meta.getDisplayName() : "No name") + "'");

            if (meta.hasDisplayName() &&
                    ChatColor.stripColor(meta.getDisplayName()).equals(ChatColor.stripColor(expectedName))) {

                Block beacon = event.getBlock();

                // Check if beacon is being placed in the Overworld
                if (!beacon.getWorld().getEnvironment().equals(org.bukkit.World.Environment.NORMAL)) {
                    event.setCancelled(true);
                    String worldType = beacon.getWorld().getEnvironment().name();
                    event.getPlayer().sendMessage("§c✗ Ritual beacons can only be placed in the Overworld!");
                    event.getPlayer().sendMessage("§7Current world: " + worldType);
                    event.getPlayer().sendMessage("§7Please go to the Overworld to place the ritual beacon.");
                    return;
                }

                // Check spawn radius restriction
                if (!isWithinSpawnRadius(beacon)) {
                    event.setCancelled(true);
                    int maxDistance = plugin.getConfigManager().getSpawnRadiusMaxDistance();
                    int currentDistance = (int) getDistanceFromSpawn(beacon);
                    event.getPlayer().sendMessage(
                            "§c✗ Ritual beacons can only be placed within " + maxDistance + " blocks of spawn!");
                    event.getPlayer().sendMessage("§7Current distance: " + currentDistance + " blocks");
                    event.getPlayer().sendMessage(
                            "§7Please get within " + maxDistance + " blocks of spawn to place the ritual beacon.");
                    return;
                }

                // Check if beacon is placed on a 3x3 iron platform
                if (!hasValidIronPlatform(beacon)) {
                    event.setCancelled(true);
                    event.getPlayer().sendMessage("§c✗ Ritual beacons must be placed on a 3x3 iron block platform!");
                    event.getPlayer()
                            .sendMessage("§7Create a 3x3 iron block platform and place the beacon in the center.");
                    return;
                }

                // Mark this beacon as a ritual beacon
                beacon.setMetadata("ritual_beacon", new FixedMetadataValue(plugin, true));

                event.getPlayer().sendMessage("§5✨ Ritual beacon has been placed! Right-click to start the ritual.");
                plugin.getLogger().info("Ritual beacon marked at " + beacon.getLocation());
            } else {
                event.getPlayer().sendMessage(
                        "§7Normal beacon placed. To create a ritual beacon, rename it to '§5Mace Ritual§7' in an anvil first.");
            }
        } else {
            event.getPlayer().sendMessage(
                    "§7Normal beacon placed. To create a ritual beacon, rename it to '§5Mace Ritual§7' in an anvil first.");
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();

        // Protect ritual beacons during active rituals
        if (block.hasMetadata("ritual_protected")) {
            event.setCancelled(true);
            event.getPlayer().sendMessage("§cThis beacon is protected during the ritual!");
            return;
        }

        // Protect iron platform blocks during active rituals
        if (block.hasMetadata("ritual_platform_protected")) {
            event.setCancelled(true);
            event.getPlayer().sendMessage("§c⚠️ The ritual platform is protected during the ritual!");
            event.getPlayer().sendMessage("§7The 3x3 iron platform cannot be broken while the ritual is active.");
            event.getPlayer().sendMessage("§7Wait for the ritual to complete or be canceled.");
            return;
        }

        // Remove ritual beacon metadata when broken
        if (block.hasMetadata("ritual_beacon")) {
            block.removeMetadata("ritual_beacon", plugin);
        }
    }

    private void setupBeaconBase(Block beacon) {
        // Create a simple iron base under the beacon to activate the beam
        Block baseBlock = beacon.getRelative(0, -1, 0);

        // Only set base if it's air or a replaceable block
        if (baseBlock.getType() == Material.AIR || baseBlock.getType().isSolid() == false) {
            baseBlock.setType(Material.IRON_BLOCK);

            // Mark the base block so we can remove it later if needed
            baseBlock.setMetadata("ritual_beacon_base", new FixedMetadataValue(plugin, true));
        }

        // Force beacon to update and show beam
        beacon.getState().update(true);
    }

    private boolean hasValidIronPlatform(Block beacon) {
        // Check if beacon is placed on center of a 3x3 iron block platform
        Block baseCenter = beacon.getRelative(0, -1, 0);

        // Check all 9 blocks in a 3x3 pattern under the beacon
        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                Block platformBlock = baseCenter.getRelative(x, 0, z);
                if (platformBlock.getType() != Material.IRON_BLOCK) {
                    return false;
                }
            }
        }

        return true;
    }

    private boolean isWithinSpawnRadius(Block beacon) {
        if (!plugin.getConfigManager().isSpawnRadiusEnabled()) {
            return true; // No restriction if disabled
        }

        double maxDistance = plugin.getConfigManager().getSpawnRadiusMaxDistance();
        double currentDistance = getDistanceFromSpawn(beacon);

        return currentDistance <= maxDistance;
    }

    private double getDistanceFromSpawn(Block beacon) {
        org.bukkit.Location beaconLocation = beacon.getLocation();
        org.bukkit.Location spawnLocation;

        if (plugin.getConfigManager().useWorldSpawn()) {
            // Use world spawn location
            spawnLocation = beaconLocation.getWorld().getSpawnLocation();
        } else {
            // Use server spawn location (first world spawn)
            spawnLocation = plugin.getServer().getWorlds().get(0).getSpawnLocation();
        }

        // Calculate 2D distance (ignore Y coordinate for spawn radius)
        double deltaX = beaconLocation.getX() - spawnLocation.getX();
        double deltaZ = beaconLocation.getZ() - spawnLocation.getZ();

        return Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
    }

    private boolean isRitualBeacon(Block block) {
        // Check if beacon has ritual metadata
        return block.hasMetadata("ritual_beacon");
    }
}