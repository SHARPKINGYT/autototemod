package com.maceritual.listeners;

import com.maceritual.MaceRitualPlugin;
import com.maceritual.utils.ItemUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Iterator;

public class PlayerListener implements Listener {

    private final MaceRitualPlugin plugin;

    public PlayerListener(MaceRitualPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        if (!plugin.getConfigManager().allowMaceDropOnDeath()) {
            // Remove True Mace from drops if configured
            Iterator<ItemStack> iterator = event.getDrops().iterator();
            while (iterator.hasNext()) {
                ItemStack item = iterator.next();
                if (ItemUtils.isTrueMace(item)) {
                    iterator.remove();
                    event.getEntity().sendMessage("§6The One True Mace has vanished upon your death!");
                    break;
                }
            }
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        // Check if only one mace is allowed and player has one
        if (plugin.getConfigManager().onlyOneMaceAllowed()) {
            checkForDuplicateMaces(player);
        }
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player))
            return;

        Player attacker = (Player) event.getDamager();
        ItemStack weapon = attacker.getInventory().getItemInMainHand();

        // Block damage from broken mace
        if (ItemUtils.isBrokenMace(weapon)) {
            event.setCancelled(true);
            attacker.sendMessage("§8The broken mace is too damaged to deal any harm!");

            // Play disappointing sound effect
            attacker.playSound(attacker.getLocation(), org.bukkit.Sound.BLOCK_ANVIL_LAND, 0.3f, 0.5f);

            // Show particle effect to indicate uselessness
            attacker.getWorld().spawnParticle(org.bukkit.Particle.SMOKE,
                    attacker.getLocation().add(0, 1, 0), 3, 0.2, 0.2, 0.2, 0.01);
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        ItemStack item = event.getItem();
        if (item == null)
            return;

        // Block broken mace interactions (except placing in ritual)
        if (ItemUtils.isBrokenMace(item)) {
            if (event.getAction().name().contains("BLOCK")) {
                // Allow block interactions for ritual placement
                return;
            }

            // Block other interactions
            if (event.getAction().name().contains("RIGHT_CLICK") ||
                    event.getAction().name().contains("LEFT_CLICK")) {
                event.setCancelled(true);
                event.getPlayer().sendMessage("§8The broken mace feels lifeless in your hands...");

                // Play subtle disappointing sound
                event.getPlayer().playSound(event.getPlayer().getLocation(),
                        org.bukkit.Sound.BLOCK_STONE_BUTTON_CLICK_OFF, 0.2f, 0.5f);
            }
        }
    }

    private void checkForDuplicateMaces(Player player) {
        int maceCount = 0;

        // Check player inventory
        for (ItemStack item : player.getInventory().getContents()) {
            if (ItemUtils.isTrueMace(item)) {
                maceCount++;
            }
        }

        // If player has more than one True Mace, remove extras
        if (maceCount > 1) {
            int removed = 0;
            for (int i = 0; i < player.getInventory().getSize(); i++) {
                ItemStack item = player.getInventory().getItem(i);
                if (ItemUtils.isTrueMace(item) && removed < maceCount - 1) {
                    player.getInventory().setItem(i, null);
                    removed++;
                }
            }

            if (removed > 0) {
                player.sendMessage("§c" + removed + " duplicate True Mace(s) have been removed. Only one may exist!");
            }
        }
    }
}