package com.maceritual;

import com.maceritual.commands.MaceRitualCommand;
import com.maceritual.commands.RitualCommand;
import com.maceritual.listeners.BeaconListener;
import com.maceritual.listeners.CraftingListener;
import com.maceritual.listeners.PlayerListener;
import com.maceritual.managers.ConfigManager;
import com.maceritual.managers.RitualManager;
import com.maceritual.managers.RecipeManager;
import org.bukkit.plugin.java.JavaPlugin;

public class MaceRitualPlugin extends JavaPlugin {
    
    private static MaceRitualPlugin instance;
    private ConfigManager configManager;
    private RitualManager ritualManager;
    private RecipeManager recipeManager;
    
    @Override
    public void onEnable() {
        instance = this;
        
        // Initialize managers
        configManager = new ConfigManager(this);
        ritualManager = new RitualManager(this);
        recipeManager = new RecipeManager(this);
        
        // Register listeners
        getServer().getPluginManager().registerEvents(new BeaconListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new CraftingListener(this), this);
        
        // Register commands
        getCommand("ritual").setExecutor(new RitualCommand(this));
        getCommand("maceritual").setExecutor(new MaceRitualCommand(this));
        
        // Initialize recipes
        recipeManager.registerBrokenMaceRecipe();
        
        getLogger().info("MaceRitual plugin has been enabled!");
    }
    
    @Override
    public void onDisable() {
        if (ritualManager != null) {
            ritualManager.cleanup();
        }
        getLogger().info("MaceRitual plugin has been disabled!");
    }
    
    public static MaceRitualPlugin getInstance() {
        return instance;
    }
    
    public ConfigManager getConfigManager() {
        return configManager;
    }
    
    public RitualManager getRitualManager() {
        return ritualManager;
    }
    
    public RecipeManager getRecipeManager() {
        return recipeManager;
    }
}