# MaceRitual Plugin

A custom Paper plugin for Minecraft 1.21.1 that adds a unique ritual system to craft and awaken **The One True Mace** - a mythical weapon of legend.

## Features

### 🔨 Broken Mace Crafting
- **Blocks ALL vanilla mace crafting** - only custom ritual maces can be created
- Custom shapeless/shaped recipe (configurable)
- Default ingredients: Netherite Ingot, 2x Echo Shard, Totem of Undying, Dragon's Breath
- Creates an unbreakable "§8Broken Mace" with NBT tag
- **Broken Mace is COMPLETELY USELESS:**
  - Cannot deal damage to any entity
  - Cannot break blocks or interact with world
  - Plays disappointing sounds when attempted to use
  - Clear visual feedback with particles and messages
  - Enhanced lore explaining its useless state
- Recipe fully editable via commands or config
- Prevents vanilla mace crafting in both crafting tables and crafter blocks

### 🕹️ Ritual System
- **Normal beacons work as vanilla** - no interference with regular gameplay
- Rename a beacon to "§5Mace Ritual" in an anvil, then place it
- Only renamed beacons become ritual beacons
- Right-click ritual beacon to open ritual GUI
- Custom square GUI with central slot for Broken Mace
- Only works in the Overworld
- One ritual at a time server-wide

### 🧪 Ritual Mechanics
- 30-minute duration (configurable)
- Cannot be canceled by death, logout, or beacon destruction
- Beacon becomes indestructible during ritual
- **Real-time Boss Bar** showing remaining time for all players
- Global server broadcasts every 5 minutes
- **Enhanced Visual Effects:**
  - Beacon beam (vanilla)
  - Swirling black smoke particles in 5-block circle
  - Rising purple mystical particles
  - Soul particles for atmospheric effect
  - Ambient beacon sounds during ritual
  - **Epic completion effects:**
    - Lightning strike
    - Explosion particle burst
    - Golden totem particles
    - Dramatic completion sounds

### ⚔️ The One True Mace
- **Name:** §6The One True Mace
- **Lore:** §7Forged through ritual and blood.
- **Enchantments:** Sharpness V, Knockback II, Unbreaking X
- Unbreakable and glowing
- Only one can exist at a time (configurable)
- Drop on death configurable

## Commands

### Admin Commands (OP only)
- `/ritual cancel` - Force-cancel active ritual
- `/maceritual reload` - Reload configuration
- `/maceritual recipe` - **Open 3x3 Crafting Table Recipe Editor** (players only)
  - **Real 3x3 crafting grid** interface
  - **Drag & drop items** from your inventory directly
  - **Visual recipe preview** with Broken Mace result
  - **Toggle shaped/shapeless** recipes with one click
  - **Right-click to remove** items from grid
  - **Left-click to place/replace** items in grid
  - **Save/Clear/Back buttons** with confirmation
  - **Professional crafting table layout** with instructions
  - **Sound effects** for better user experience
- Legacy text commands (console compatible):
  - `/maceritual recipe add <material>` - Add ingredient
  - `/maceritual recipe remove <index>` - Remove ingredient
  - `/maceritual recipe type <shaped|shapeless>` - Change recipe type

## Configuration

```yaml
# Ritual duration in seconds (default: 1800 = 30 minutes)
ritual_duration: 1800

# Broadcast interval in seconds (default: 300 = 5 minutes)  
broadcast_interval: 300

# Whether the True Mace drops on player death
allow_mace_drop_on_death: true

# Whether only one True Mace can exist at a time
only_one_mace_allowed: true

# The display name required for ritual beacons
beacon_block_name: "§5Mace Ritual"

# Recipe configuration
recipe:
  shaped: false
  ingredients:
    - "NETHERITE_INGOT"
    - "ECHO_SHARD" 
    - "ECHO_SHARD"
    - "TOTEM_OF_UNDYING"
    - "DRAGON_BREATH"
```

## Installation

1. Download the plugin JAR file
2. Place it in your server's `plugins/` folder
3. Restart your server
4. Configure settings in `plugins/MaceRitual/config.yml` if needed

## Usage Guide

1. **Craft a Broken Mace:**
   - Gather the required materials (check config)
   - Use a crafting table to create the Broken Mace

2. **Prepare the Ritual:**
   - Place a beacon in the Overworld
   - Rename the beacon to "§5Mace Ritual" using an anvil
   - Ensure you have the Broken Mace in your inventory

3. **Start the Ritual:**
   - Right-click the renamed beacon
   - Place the Broken Mace in the central slot
   - Click "Start Ritual"
   - Wait 30 minutes for completion

4. **Claim Your Reward:**
   - After 30 minutes, lightning will strike
   - The One True Mace will drop at the ritual location
   - Pick it up and enjoy your legendary weapon!

## Permissions

- `maceritual.admin` - Access to all admin commands (default: OP)
- `maceritual.use` - Ability to use the ritual system (default: true)

## Compatibility

- **Server:** Paper 1.21.1+
- **Java:** 17+
- **Dependencies:** None (standalone plugin)

## Technical Details

- Uses BukkitRunnable for non-blocking ritual timing
- NBT tags for item uniqueness and validation
- Metadata for beacon protection during rituals
- Particle effects and lightning strikes for immersion
- Clean event handling and resource management

---

*Forge your legend with The One True Mace!* ⚔️