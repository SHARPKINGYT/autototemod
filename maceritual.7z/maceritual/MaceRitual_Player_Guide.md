# 🗡️ **MACE RITUAL PLUGIN - PLAYER GUIDE** ⚔️

## 📖 **OVERVIEW**
The MaceRitual plugin adds an exclusive, server-wide quest to obtain **The One True Mace** - a legendary weapon that can only be forged once per server! This guide will walk you through the entire process.

---

## ⚠️ **IMPORTANT: ONE-TIME ONLY SYSTEM**
- **Only ONE player** can ever complete this ritual on the server
- **Only ONE True Mace** will ever exist
- Once completed, the ritual cannot be performed again
- This creates ultimate exclusivity and competition!

---

## 🔧 **STEP 1: CRAFT THE BROKEN MACE**

Recipe provided by admins.

### How to Craft:
1. Gather all required materials
2. place all items in any order in crafting table
3. You'll receive the **Broken Mace** ⚔️

> **Note:** Only ONE Broken Mace can ever be crafted per server!

---

## 🏗️ **STEP 2: PREPARE THE RITUAL SITE**

### Requirements:
- Must be in the **Overworld** (not Nether or End)
- Must be within **5,000 blocks** of spawn
- Need **9 Iron Blocks** for the platform
- Need **1 Beacon**

### Setup Instructions:
1. **Create a 3x3 Iron Block Platform**
   ```
   [I] [I] [I]
   [I] [I] [I]  ← Place beacon on center iron block
   [I] [I] [I]
   ```

2. **Rename the Beacon**
   - Use an **Anvil** to rename your beacon
   - Rename it to: `Mace Ritual` (exactly as shown)

3. **Place the Ritual Beacon**
   - Place the renamed beacon on the **center** of your 3x3 iron platform
   - You'll see: "✨ Ritual beacon has been placed! Right-click to start the ritual."

---

## 🔮 **STEP 3: START THE RITUAL**

### How to Begin:
1. **Right-click** the ritual beacon
2. A GUI will open showing ritual requirements
3. **Place your Broken Mace** in the GUI slot
4. Click **"Start Ritual"** button

### What Happens:
- **30-minute countdown** begins
- **Boss bar** appears showing remaining time
- **Particle effects** surround the beacon (smoke, purple particles, souls)
- **Server-wide announcements** every 5 minutes
- **Beacon and platform become protected** (unbreakable)

---

## ⏰ **STEP 4: WAIT AND PROTECT**

### During the Ritual:
- **Duration:** 30 minutes (1800 seconds)
- **Boss Bar:** Shows countdown with color changes:
  - 🟢 **Green:** 20+ minutes remaining
  - 🟡 **Yellow:** 10-20 minutes remaining  
  - 🔴 **Red:** Less than 10 minutes remaining
- **Visual Effects:** Swirling smoke, purple particles, soul effects
- **Protection:** Beacon and iron platform cannot be broken by anyone
- **Server Announcements:** Location broadcasts every 5 minutes

### Important Notes:
- **Only one ritual** can be active at a time
- **Cannot be interrupted** by players (protected blocks)
- **Admins can cancel** if needed with `/maceritual cancel`
- **Server restarts** will cancel the ritual

---

## 🎉 **STEP 5: RITUAL COMPLETION**

### When the Timer Reaches Zero:
1. **Lightning strikes** the beacon ⚡
2. **Dramatic sound effects** play
3. **Explosion particles** and **golden particle burst**
4. **Server-wide announcement:** "The Ritual is complete!"
5. **The One True Mace** drops above the beacon

### The One True Mace Features:
- **Legendary weapon** with enhanced stats
- **Unique appearance** and lore
- **Only one exists** on the entire server
- **Drops on death** (configurable by admins)

---

## 🚫 **RESTRICTIONS & LIMITATIONS**

### Location Restrictions:
- ❌ **Nether/End:** Cannot place beacons or perform rituals
- ❌ **Too far from spawn:** Must be within 5,000 blocks
- ❌ **Wrong platform:** Must be exactly 3x3 iron blocks

### One-Time System:
- ❌ **Already crafted:** Cannot craft another Broken Mace
- ❌ **Already completed:** Cannot perform ritual again
- ❌ **Multiple rituals:** Only one ritual can be active

### Protection During Ritual:
- ❌ **Beacon breaking:** Protected during ritual
- ❌ **Platform breaking:** 3x3 iron platform protected
- ❌ **Applies to everyone:** Even OPs cannot break protected blocks

---

## 💡 **TIPS & STRATEGIES**

### For Success:
- **Gather materials early** - competition will be fierce!
- **Choose location wisely** - consider defense and accessibility
- **Coordinate with friends** - protect the ritual site
- **Monitor server announcements** - know when others attempt rituals

### For Competition:
- **Scout other players** - watch for material gathering
- **Monitor chat** - ritual announcements reveal locations
- **Be prepared** - have backup materials ready
- **Act fast** - first to complete wins everything

---

## 🛠️ **ADMIN COMMANDS** (For Reference)

Players cannot use these, but admins have:
- `/maceritual reload` - Reload configuration
- `/maceritual cancel` - Cancel active ritual
- `/maceritual reset` - Reset one-time system
- `/maceritual status` - Check ritual status
- `/maceritual give <player> <item>` - Give items for testing

---

## ❓ **TROUBLESHOOTING**

### Common Issues:

**"Ritual beacons can only be placed in the Overworld!"**
- Solution: Go to the Overworld, not Nether or End

**"Must be placed on a 3x3 iron block platform!"**
- Solution: Create exactly 3x3 iron blocks, place beacon in center

**"Can only be placed within 5000 blocks of spawn!"**
- Solution: Move closer to spawn point

**"The Mace Ritual has already been completed once!"**
- Solution: Too late! Someone else got the True Mace

**"A ritual is already in progress!"**
- Solution: Wait for current ritual to finish or be canceled

---

## 🏆 **CONCLUSION**

The MaceRitual plugin creates the ultimate server competition - only ONE player will ever obtain The One True Mace! Gather your materials, choose your location, and may the best player win!

**Good luck, and may the ritual be with you!** ⚔️✨

---

*Plugin Version: 1.0.0 | Minecraft 1.21.1 | Paper Server*